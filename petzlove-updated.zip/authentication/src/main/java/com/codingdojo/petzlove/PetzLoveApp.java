package com.codingdojo.petzlove;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetzLoveApp {

	public static void main(String[] args) {
		SpringApplication.run(PetzLoveApp.class, args);
	}

}
