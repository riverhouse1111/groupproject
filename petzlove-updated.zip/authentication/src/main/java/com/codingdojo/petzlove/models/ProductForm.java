package com.codingdojo.petzlove.models;

public class ProductForm {
	
	private String name;
	private String desc;
	private Long price;
	private Long stock;
	private Long petid;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public Long getPrice() {
		return price;
	}
	public void setPrice(Long price) {
		this.price = price;
	}
	public Long getStock() {
		return stock;
	}
	public void setStock(Long stock) {
		this.stock = stock;
	}
	
	public Long getPetid() {
		return petid;
	}
	public void setPetid(Long petid) {
		this.petid = petid;
	}
}

