package com.codingdojo.petzlove.services;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.codingdojo.petzlove.models.Product;
import com.codingdojo.petzlove.repositories.ProductRepository;

@Service
public class ProductService {
	private final ProductRepository productRepository;
	
	public ProductService(ProductRepository prodRepository) {
		this.productRepository = prodRepository;
	}
	
	public List<Product> allGames() {
		return productRepository.findAll();
	}
	
	public Product createProduct(Product prod) {
		return productRepository.save(prod);
	}
	
	public Product findProduct(Long id) {
		Optional<Product> prodOptional = productRepository.findById(id);
		return prodOptional.orElse(null);
	}
	
	public Product updateProduct(Long id, String name, String desc, Long price, Long stock, Long petid) {
		Product prod = productRepository.findById(id).orElse(null);
		if (prod != null) {
			prod.setpName(name);
			prod.setpDesc(desc);
			prod.setpPrice(price);
			prod.setpStock(stock);
			prod.setpPetID(petid);
			return productRepository.save(prod);
		}
		return null;
	}
	
	public Product updateProductFromProd(Product game) {
		return productRepository.save(game);
	}
	
	public void deleteProduct(Long id) {
		productRepository.deleteById(id);
	}
	
	public List<Product> productsAlphabetical() {
	    List<Product> prods = productRepository.findAll();
	    prods.sort(Comparator.comparing(Product::getpName));
	    return prods;
	}
}
