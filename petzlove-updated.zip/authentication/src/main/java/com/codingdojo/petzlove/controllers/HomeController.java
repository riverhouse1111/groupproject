package com.codingdojo.petzlove.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.codingdojo.petzlove.models.Product;
import com.codingdojo.petzlove.models.ProductForm;
import com.codingdojo.petzlove.models.LoginUser;
import com.codingdojo.petzlove.models.User;
import com.codingdojo.petzlove.services.ProductService;
import com.codingdojo.petzlove.services.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
public class HomeController {
    
    @Autowired
    private UserService userServ;
    
    @Autowired
    private ProductService prodServ;
    
    @GetMapping("/")
    public String index(Model model) {
    
        model.addAttribute("newUser", new User());
        model.addAttribute("newLogin", new LoginUser());
        return "index";
    }
    
    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("newUser") User newUser, 
            BindingResult result, Model model, HttpSession session) {
        
    	User registeredUser = userServ.register(newUser, result);
        
        if(result.hasErrors()) {

            model.addAttribute("newLogin", new LoginUser());
            return "index";
        }
        
        session.setAttribute("userId", registeredUser.getId());
    
        return "redirect:/home";
    }
    
    @PostMapping("/login")
    public String login(@Valid @ModelAttribute("newLogin") LoginUser newLogin, 
            BindingResult result, Model model, HttpSession session) {
        
    	User user = userServ.login(newLogin, result);
    
        if(result.hasErrors()) {
            model.addAttribute("newUser", new User());
            return "index";
        }
    
        session.setAttribute("userId", user.getId());
    
        return "redirect:/home";
    }
    
    @GetMapping("/home")
    public String home(Model model, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/";
        }

        User user = userServ.findUser(userId);
        model.addAttribute("username", user.getUserName());

        List<Product> products = prodServ.productsAlphabetical();
        model.addAttribute("products", products);

        return "home";
    }

    
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
    
    @GetMapping("/products/new")
    public String createProduct(Model model, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/";
        }
        
        model.addAttribute("prodForm", new ProductForm());
        return "create_product";
    }
    
    @PostMapping("/products")
    public String saveProduct(@Valid @ModelAttribute("prodForm") ProductForm prodForm,
                           BindingResult result,
                           Model model,
                           HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/";
        }
        
        if (result.hasErrors()) {
            model.addAttribute("errors", result.getAllErrors());
            
            model.addAttribute("prodForm", prodForm);
            
            return "create_product";
        }
        
        User user = userServ.findUser(userId);
        
        Product prod = new Product();
        prod.setpName(prodForm.getName());
        prod.setpDesc(prodForm.getDesc());
        prod.setpPrice(prodForm.getPrice());
        prod.setpStock(prodForm.getStock());
        prod.setpPetID(prodForm.getPetid());
        prod.setUser(user);
        
        prodServ.createProduct(prod);
        
        return "redirect:/home";
    }


    @GetMapping("/products/{id}")
    public String gameInfo(@PathVariable("id") Long id, Model model, HttpSession session) {
        Product prod = prodServ.findProduct(id);
        model.addAttribute("product", prod);
        
        Long userId = (Long) session.getAttribute("userId");
        
        if (userId == null) {
            return "redirect:/";
        }
        
        if (userId != null && prod.getUser().getId().equals(userId)) {
        	model.addAttribute("isOwner", true);
        } else {
        	model.addAttribute("isOwner", false);
        }
        
        return "product_info";
    }

    @PostMapping("/products/{id}/delete")
    public String deleteGame(@PathVariable("id") Long pId, HttpSession session) {
    	Long userId = (Long) session.getAttribute("userId");
        Product prod = prodServ.findProduct(pId);
        
        if (userId == null || !prod.getUser().getId().equals(userId)) {
        	return "redirect:/home";
        }
        
        prodServ.deleteProduct(pId);
        
        return "redirect:/home";
    }

    
    @GetMapping("/products/{id}/edit")
    public String editProduct(@PathVariable("id") Long gameId, Model model, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        Product prod = prodServ.findProduct(gameId);
        
        if (userId == null || !prod.getUser().getId().equals(userId)) {
            return "redirect:/home";
        }
        
        ProductForm prodForm = new ProductForm();
        prodForm.setName(prod.getpName());
        prodForm.setDesc(prod.getpDesc());
        prodForm.setPrice(prod.getpPrice());
        prodForm.setStock(prod.getpStock());
        prodForm.setPetid(prod.getpPetID());
        
        model.addAttribute("prodForm", prodForm);
        model.addAttribute("product", prod);
        
        return "edit_product";
    }
    
    @PostMapping("/products/{id}/update")
    public String updateProduct(@PathVariable("id") Long pId, @Valid @ModelAttribute("prodForm") ProductForm prodForm,
                             BindingResult result, Model model, HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        Product prod = prodServ.findProduct(pId);
        
        if (userId == null) {
            return "redirect:/home";
        }
        
        if (!prod.getUser().getId().equals(userId)) {
            return "redirect:/home";
        }
        
        if (result.hasErrors()) {
            return "edit_prod";
        }
        
        prod.setpName(prodForm.getName());
        prod.setpDesc(prodForm.getDesc());
        prod.setpPrice(prodForm.getPrice());
        prod.setpStock(prodForm.getStock());
        prod.setpPetID(prodForm.getPetid());
        
        prodServ.updateProductFromProd(prod);
        
        return "redirect:/home";
    }


}


